<template>
  <div>
    <h2>tags</h2>
  </div>
</template>

<script>
export default {
    name: "Tags"
}
</script>

<style scoped>
</style>