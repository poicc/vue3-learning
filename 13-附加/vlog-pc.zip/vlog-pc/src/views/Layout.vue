<template>
  <div>
    <h2>layout</h2>
  </div>
</template>

<script>
export default {
    name: "Layout"
}
</script>

<style scoped>
</style>