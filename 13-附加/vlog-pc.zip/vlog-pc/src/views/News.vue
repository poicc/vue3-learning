<template>
  <div>
    <h2>新闻</h2>
  </div>
</template>

<script>
export default {
    name: "News"
}
</script>

<style scoped>
</style>