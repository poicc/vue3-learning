<template>
  <div>
    <h2>消息</h2>
  </div>
</template>

<script>
export default {
    name: "Message"
}
</script>

<style scoped>
</style>