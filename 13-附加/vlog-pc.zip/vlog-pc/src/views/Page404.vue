<template>
  <div>
    <h2>404</h2>
  </div>
</template>

<script>
export default {
    name: "Page404"
}
</script>

<style scoped>
</style>