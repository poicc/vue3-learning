<template>
  <div class="bg row">
    <v-form v-model="valid" lazy-validation ref="form" class="col">
      <v-text-field v-model="phone" required label="Phone" :rules="phoneRules"></v-text-field>
      <v-text-field v-model="password" required label="Password" :rules="passwordRules"></v-text-field>
      <v-checkbox v-model="checkbox" label="同意协议？" required :rules="[(v) => !!v || '同意才能继续！']"></v-checkbox>
      <v-btn color="success" class="mr-4" @click="validate">验证</v-btn>
      <v-btn color="primary" class="mr-4" @click="submit">登录</v-btn>
      <v-btn color="warning" @click="reset">重置</v-btn>
    </v-form>

    <v-overlay absolute z-index="5" class="mask"></v-overlay>
  </div>
</template>

<script>
export default {
  name: 'Login',
  data() {
    return {
      valid: true,
      phone: '13900001111',
      password: '123123',
      checkbox: false,
      phoneRules: [(v) => !!v || '手机号不能为空', (v) => (v && v.length === 11) || '手机号必须为11位'],
      passwordRules: [
        (v) => !!v || '密码不能为空',
        (v) => (v && v.length >= 6 && v.length <= 16) || '密码长度必须在6-16之间',
      ],
    }
  },
  methods: {
    validate() {
      this.$refs.form.validate()
    },
    reset() {
      this.$refs.form.reset()
    },
    submit() {
      this.axios({
        method: 'post',
        url: '/user/login',
        data: {
          phone: this.phone,
          password: this.password,
        },
      }).then((res) => {
        if (res.data.code == 1) {
          alert('登录成功')
          this.$store.commit('login', res.data.data)
          this.$router.push('/')
        }
      })
    },
  },
}
</script>

<style scoped lang="scss">
.bg {
  width: 100vw;
  height: 100vh;
  background: url('http://47.96.31.161:9000/my-file/img112.jpg');
  background-size: 100% 100%;
}
.mask {
  background-image: linear-gradient(to right,#bf30ac 0%,#0f9d58 100%);
  opacity: 0.7;
}
.row {
  display: flex;
  align-items: center;
  justify-content: center;
  .col {
    flex: 0 0 40%;
    height: 330px;
    background: #eee;
    z-index: 10;
    border-radius: 10px;
  }
}
</style>