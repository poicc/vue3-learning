<template>
  <div>
    <h2>我的</h2>
  </div>
</template>

<script>
export default {
    name: "My"
}
</script>

<style scoped>
</style>